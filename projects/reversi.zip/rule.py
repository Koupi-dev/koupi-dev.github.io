EMPTY = 0
BLACK = 1
WHITE = -1

DIRECTIONS = [
    (-1, -1), 
    (-1, 0),   
    (-1, 1),  
    (0, -1),
    (0, 1),   
    (1, -1), 
    (1, 0), 
    (1, 1),    
]

def init_board():
    board = [[EMPTY for _ in range(8)] for _ in range(8)]
    board[3][3] = WHITE
    board[3][4] = BLACK
    board[4][3] = BLACK  
    board[4][4] = WHITE 
    return board

def is_valid_move(board, x, y, player):
    if board[y][x] != EMPTY:
        return False

    for dx, dy in DIRECTIONS:
        nx, ny = x + dx, y + dy
        found_opponent = False

        while 0 <= nx < 8 and 0 <= ny < 8:
            cell = board[ny][nx]
            if cell == -player:
                found_opponent = True
            elif cell == player:
                if found_opponent:
                    return True
                else:
                    break
            else:
                break

            nx += dx
            ny += dy

    return False 

def get_valid_moves(board, player):
    moves = []
    for y in range(8):
        for x in range(8):
            if is_valid_move(board, x, y, player):
                moves.append((x, y))
    return moves

def apply_move(board, x, y, player):
    board[y][x] = player 

    for dx, dy in DIRECTIONS:
        nx, ny = x + dx, y + dy
        path = []

        while 0 <= nx < 8 and 0 <= ny < 8:
            cell = board[ny][nx]
            if cell == -player:
                path.append((nx, ny)) 
            elif cell == player:
                for px, py in path:
                    board[py][px] = player 
                break
            else:
                break 
            nx += dx
            ny += dy
