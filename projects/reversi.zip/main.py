import os
import numpy as np
import random
from rule import init_board, get_valid_moves, apply_move, BLACK, WHITE, DIRECTIONS
from gymnasium import Env
from gymnasium.spaces import Box, Discrete
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env

class OthelloEnv(Env):
    def __init__(self):
        super().__init__()
        self.observation_space = Box(low=-1, high=1, shape=(8, 8), dtype=np.int8)
        self.action_space = Discrete(64)
        self.board = None
        self.current_player = BLACK
        self.pass_count = 0

    def reset(self, seed=None, options=None):
        self.board = init_board()
        self.current_player = BLACK
        self.pass_count = 0
        return np.array(self.board, dtype=np.int8), {}

    def step(self, action):
        valid_moves = get_valid_moves(self.board, self.current_player)

        if self.current_player == BLACK:
            x, y = action % 8, action // 8
            if (x, y) not in valid_moves:
                if valid_moves:
                    x, y = random.choice(valid_moves)
                else:
                    self.pass_count += 1
                    done = self.pass_count >= 2 or is_full(self.board)
                    return np.array(self.board, dtype=np.int8), -1.0, done, False, {}
            apply_move(self.board, x, y, self.current_player)
            reward = 5.0 if (x, y) in [(0,0),(0,7),(7,0),(7,7)] else 0.0
            reward += count_flips(self.board, x, y, self.current_player)
            self.current_player = WHITE
        else:
            if valid_moves:
                move = random.choice(valid_moves)
                apply_move(self.board, move[0], move[1], self.current_player)
            self.current_player = BLACK
            reward = 0.0

        if not get_valid_moves(self.board, self.current_player):
            self.pass_count += 1
        else:
            self.pass_count = 0

        done = self.pass_count >= 2 or is_full(self.board)
        return np.array(self.board, dtype=np.int8), reward, done, False, {}

    def render(self):
        symbols = {0: '.', 1: 'B', -1: 'W'}
        print("  " + " ".join(str(x) for x in range(8)))
        for y in range(8):
            row = " ".join(symbols[self.board[y][x]] for x in range(8))
            print(f"{y} {row}")
        print()

def count_flips(board, x, y, player):
    count = 0
    for dx, dy in DIRECTIONS:
        nx, ny = x + dx, y + dy
        temp = 0
        while 0 <= nx < 8 and 0 <= ny < 8 and board[ny][nx] == -player:
            temp += 1
            nx += dx
            ny += dy
        if 0 <= nx < 8 and 0 <= ny < 8 and board[ny][nx] == player:
            count += temp
    return count

def is_full(board):
    return all(cell != 0 for row in board for cell in row)

def battle(model_a, model_b, num_matches=100):
    a_wins, b_wins = 0, 0
    for _ in range(num_matches):
        env = OthelloEnv()
        obs, _ = env.reset()
        done = False
        while not done:
            if env.current_player == BLACK:
                action, _ = model_a.predict(obs)
            else:
                action, _ = model_b.predict(obs)
            obs, _, done, _, _ = env.step(action)

        black = sum(row.count(BLACK) for row in env.board)
        white = sum(row.count(WHITE) for row in env.board)
        if black > white:
            a_wins += 1
        elif white > black:
            b_wins += 1
    return a_wins, b_wins

def evolve():
    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)

    latest = -1
    for f in os.listdir(model_dir):
        if f.startswith("othello_gen") and f.endswith(".zip"):
            try:
                n = int(f[len("othello_gen"):-4])
                latest = max(latest, n)
            except:
                pass

    generation = latest + 1
    if latest >= 0:
        print(f"📅 前の世代読み込み: othello_gen{latest}.zip")
        prev_model = PPO.load(os.path.join(model_dir, f"othello_gen{latest}.zip"), env=make_vec_env(OthelloEnv, n_envs=4))
    else:
        print("🧪 初期モデル作成中...")
        prev_model = PPO("MlpPolicy", make_vec_env(OthelloEnv, n_envs=4), verbose=0, learning_rate=1e-4)
        prev_model.save(os.path.join(model_dir, "othello_gen0.zip"))
        print("✅ 初代モデル保存済み")
        latest = 0

    while True:
        print(f"\n=== 🌱 世代 {generation} ===")
        env = make_vec_env(OthelloEnv, n_envs=4)
        new_model = PPO("MlpPolicy", env, verbose=0, learning_rate=1e-4)
        new_model.set_parameters(prev_model.get_parameters())
        new_model.learn(total_timesteps=500_000, reset_num_timesteps=True)

        print("🧪 評価中...")
        prev_model_for_eval = PPO.load(os.path.join(model_dir, f"othello_gen{latest}.zip"), env=make_vec_env(OthelloEnv, n_envs=1))
        a, b = battle(prev_model_for_eval, new_model, num_matches=100)
        print(f"🧨 前世代: {a}勝, 🧩 現世代: {b}勝")

        if b > a:
            new_model.save(os.path.join(model_dir, f"othello_gen{generation}.zip"))
            print(f"🎉 現世代が勝利！→ 保存完了: othello_gen{generation}.zip")
            prev_model = new_model
            latest = generation
            generation += 1
        else:
            print("🗑️ 弱体化したので後回し")

if __name__ == "__main__":
    mode = input("train/test/evolve? > ").strip().lower()
    if mode == "train":
        print("💤 trainはデフォでは使用しないようにしています")
    elif mode == "test":
        model = PPO.load("othello_model")
        env = OthelloEnv()
        obs, _ = env.reset()
        done = False
        while not done:
            env.render()
            action, _ = model.predict(obs)
            obs, _, done, _, _ = env.step(action)
        env.render()
    elif mode == "evolve":
        evolve()
    else:
        print("🤡 'train' か 'test' か 'evolve' 入れてね")
